import {parseLogText,analyzeLogs,compareReports,comparisonToCsv} from './analyzer.js?v=4.4.0-preview.2';
import {unzipLoga} from './zip.js?v=4.4.0-preview.2';

const $=selector=>document.querySelector(selector);
const MAX_FILES=20,MAX_FILE_BYTES=25*1024*1024;
const MAX_TOTAL_FILE_BYTES=100*1024*1024,MAX_TOTAL_ROWS=500000;
let beforeFiles=[],afterFiles=[],latestComparison=null;

function esc(value){return String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));}
function fmt(value,n=2){return value==null?'—':Number(value).toFixed(n);}
function signed(value,n=1){if(value==null)return'—';const number=Number(value);return `${number>0?'+':''}${number.toFixed(n)}%`;}
function setStatus(text,bad=false){$('#compareStatus').textContent=text;$('#compareStatus').className=bad?'bad':'';}
function updateRun(){
  $('#beforeList').innerHTML=beforeFiles.length?beforeFiles.map(f=>`<span class="chip">${esc(f.name)}</span>`).join(''):'尚未選擇';
  $('#afterList').innerHTML=afterFiles.length?afterFiles.map(f=>`<span class="chip">${esc(f.name)}</span>`).join(''):'尚未選擇';
  $('#compareRun').disabled=!beforeFiles.length||!afterFiles.length;
}
function validate(files){
  const next=[...files];
  if(next.length>MAX_FILES)throw new Error(`每組最多 ${MAX_FILES} 個 Log`);
  for(const file of next){
    if(!/\.(?:loga|log|txt|csv|zip)$/i.test(file.name))throw new Error('支援 .loga / .log / .txt / .csv / .zip');
    if(file.size>MAX_FILE_BYTES)throw new Error(`${file.name} 超過 25 MB 上限`);
  }
  if(next.reduce((total,file)=>total+file.size,0)>MAX_TOTAL_FILE_BYTES)throw new Error('每組 Log 總容量超過 100 MB 上限');
  return next;
}
function setupDrop(prefix,setFiles){
  const input=$(`#${prefix}Files`),drop=$(`#${prefix}Drop`);
  const select=files=>{try{setFiles(validate(files));setStatus('');updateRun();}catch(error){setStatus(error.message,true);}};
  input.addEventListener('change',()=>select(input.files));
  drop.addEventListener('click',()=>input.click());
  drop.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();input.click();}});
  ['dragenter','dragover'].forEach(name=>drop.addEventListener(name,event=>{event.preventDefault();drop.classList.add('drag');}));
  ['dragleave','drop'].forEach(name=>drop.addEventListener(name,event=>{event.preventDefault();drop.classList.remove('drag');}));
  drop.addEventListener('drop',event=>select(event.dataTransfer.files));
}
setupDrop('before',files=>{beforeFiles=files;});
setupDrop('after',files=>{afterFiles=files;});

async function load(files){
  const logs=[];let totalRows=0;
  const addLog=(name,text)=>{
    const rows=parseLogText(text,name);totalRows+=rows.length;
    if(totalRows>MAX_TOTAL_ROWS)throw new Error('每組 Log 解析後總資料超過 500,000 列上限；請分批比較。');
    logs.push({name,rows,platform:rows.meta?.platform??'unknown'});
  };
  for(const file of files){
    if(/\.zip$/i.test(file.name)){
      const entries=await unzipLoga(await file.arrayBuffer());
      for(const entry of entries)addLog(`${file.name}/${entry.name}`,entry.text);
    }else addLog(file.name,await file.text());
  }
  return logs;
}
function settings(){return{
  ecuModel:'MiniXX',logPlatform:$('#compareLogPlatform').value,fuelClMode:$('#compareFuelClMode').value,
  minEngineTemp:Number($('#compareMinTemp').value),entryWaitSeconds:Number($('#compareEntryWait').value),
  minStableSecondsAfterWait:Number($('#compareMinStable').value),accExclusionSeconds:Number($('#compareAccWait').value),
  minSamplesPerCell:Number($('#compareMinSamples').value),
  maxSuggestionPct:Number($('#compareMaxSuggest').value)
};}
const resultLabel={Improved:'改善',Worse:'惡化',Similar:'近似',Overcorrected:'可能修過頭','Low confidence':'可信度不足','Only one side':'單側資料'};
function comparisonCellText(cell,display){
  if(display==='before')return signed(cell.beforeCorrectionPct,1);
  if(display==='after')return signed(cell.afterCorrectionPct,1);
  if(display==='change')return signed(cell.correctionChangePct,1);
  if(cell.result==='Only one side'||cell.absoluteErrorChangePct==null)return '單側資料';
  return `${resultLabel[cell.result]} ${Math.abs(cell.absoluteErrorChangePct).toFixed(1)}%`;
}
function renderMap(comparison){
  const display=$('#compareDisplay').value;
  const by=new Map(comparison.cells.map(c=>[`${c.tps}|${c.rpm}`,c]));
  let html='<table class="map comparisonMap"><thead><tr><th>TPS\\RPM</th>'+comparison.axes.fuelRpmAxis.map(rpm=>`<th>${rpm}</th>`).join('')+'</tr></thead><tbody>';
  for(const tps of comparison.axes.fuelTpsAxis){
    html+=`<tr><th>${tps}%</th>`;
    for(const rpm of comparison.axes.fuelRpmAxis){
      const cell=by.get(`${tps}|${rpm}`);
      if(!cell){html+='<td class="empty">—</td>';continue;}
      const cls=cell.result==='Improved'?'improved':cell.result==='Worse'?'worse':cell.result==='Overcorrected'?'overcorrected':cell.result==='Similar'?'similar':'onlyOne';
      const title=`${tps}% / ${rpm} rpm；${resultLabel[cell.result]}；前 ${signed(cell.beforeCorrectionPct,1)}（${cell.beforeConfidence??'—'}）；後 ${signed(cell.afterCorrectionPct,1)}（${cell.afterConfidence??'—'}）；修正變化 ${signed(cell.correctionChangePct,1)}`;
      html+=`<td class="compareCell ${cls}" title="${esc(title)}"><strong>${esc(comparisonCellText(cell,display))}</strong></td>`;
    }
    html+='</tr>';
  }
  $('#compareMapWrap').innerHTML=html+'</tbody></table>';
}
function render(comparison){
  latestComparison=comparison;$('#compareResult').hidden=false;
  const s=comparison.summary;
  $('#compareSummary').innerHTML=`<div><b>${s.comparable}</b><span>可比較格位</span></div><div><b>${s.improved}</b><span>改善</span></div><div><b>${s.overcorrected}</b><span>可能修過頭</span></div><div><b>${s.worse}</b><span>惡化</span></div><div><b>${s.lowConfidence}</b><span>可信度不足</span></div><div><b>${s.similar}</b><span>近似</span></div><div><b>${s.onlyOneSide}</b><span>單側資料</span></div>`;
  renderMap(comparison);
  $('#compareDetailBody').innerHTML=comparison.cells.map(c=>`<tr><td>${c.tps}%</td><td>${c.rpm}</td><td>${fmt(c.beforeTargetAfr)}</td><td>${fmt(c.afterTargetAfr)}</td><td>${fmt(c.beforeActualAfr)}</td><td>${fmt(c.afterActualAfr)}</td><td>${signed(c.beforeCorrectionPct)}</td><td>${signed(c.afterCorrectionPct)}</td><td>${signed(c.correctionChangePct)}</td><td>${signed(c.absoluteErrorChangePct)}</td><td>${c.beforeSamples}</td><td>${c.afterSamples}</td><td>${c.beforeConfidence??'—'}</td><td>${c.afterConfidence??'—'}</td><td>${resultLabel[c.result]}</td></tr>`).join('');
}

$('#compareRun').addEventListener('click',async()=>{
  $('#compareRun').disabled=true;setStatus('正在分析兩組 Log…');
  try{
    const [before,after]=await Promise.all([load(beforeFiles),load(afterFiles)]);
    const shared=settings();
    render(compareReports(analyzeLogs(before,shared),analyzeLogs(after,shared)));
    setStatus(`完成：${before.length} 個調整前 Log、${after.length} 個調整後 Log`);
  }catch(error){console.error(error);setStatus(error.message||String(error),true);}
  finally{$('#compareRun').disabled=!beforeFiles.length||!afterFiles.length;}
});
$('#exportComparison').addEventListener('click',()=>{
  if(!latestComparison)return;
  const blob=new Blob(['\uFEFF'+comparisonToCsv(latestComparison)],{type:'text/csv;charset=utf-8'});
  const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download='minixx_before_after_v4_4_preview.csv';link.click();
  setTimeout(()=>URL.revokeObjectURL(link.href),1000);
});
$('#compareDisplay').addEventListener('change',()=>{if(latestComparison)renderMap(latestComparison);});
if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js?v=4.4.0-preview.2').catch(console.warn);
