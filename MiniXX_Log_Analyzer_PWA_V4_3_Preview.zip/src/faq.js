const $=selector=>document.querySelector(selector);
const title=$('#feedbackTitle');
const message=$('#feedbackMessage');
const button=$('#feedbackOpen');

function updateButton(){
  button.disabled=!title.value.trim()||!message.value.trim();
}

title.addEventListener('input',updateButton);
message.addEventListener('input',updateButton);

button.addEventListener('click',()=>{
  const type=$('#feedbackType').value;
  const device=$('#feedbackDevice').value.trim()||'未填寫';
  const body=[
    `問題類型：${type}`,
    `裝置／瀏覽器：${device}`,
    '',
    '詳細說明：',
    message.value.trim(),
    '',
    '網站版本：V4.3 Preview'
  ].join('\n');
  const params=new URLSearchParams({title:`[${type}] ${title.value.trim()}`,body});
  const feedbackBase=atob('aHR0cHM6Ly9naXRodWIuY29tL3N0dTk4MTE3MzEtc3Rhci9TdXBlclhYLU1pbmlYWC1Mb2ctQW5hbHl6ZXIvaXNzdWVzL25ldw==');
  const url=`${feedbackBase}?${params}`;
  const opened=window.open(url,'_blank','noopener');
  $('#feedbackStatus').textContent=opened?'已開啟回報頁，請確認內容後再送出。':'瀏覽器阻擋新視窗，請允許後再試一次。';
});
