import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeRecognizedNumber,adjustmentLabel,adjustedFuelValue,
  mergeRecognizedCells,getCurrentFuelValue,tokensToFuelCells,SCREENSHOT_RPM_AXIS
} from '../src/screenshot-map.js';

test('screenshot editor follows the supplied two-stage RPM axis through 16000',()=>{
  assert.deepEqual(SCREENSHOT_RPM_AXIS,[800,1200,1600,2000,2400,2800,3200,3600,4000,4400,4800,5200,5600,6000,6400,6800,7200,7600,8000,8400,8800,9200,9600,9800,10000,10200,10400,10600,10800,11000,11200,11400,11600,11800,12000,12200,12400,12600,12800,13000,13200,13400,13600,13800,14000,14200,14400,14600,14800,15000,15200,15400,15600,15800,16000]);
});

test('normalizes OCR number variants without inventing empty values',()=>{
  assert.equal(normalizeRecognizedNumber(' +100.8% '),100.8);
  assert.equal(normalizeRecognizedNumber('−1,6'),-1.6);
  assert.equal(normalizeRecognizedNumber('O.8'),0.8);
  assert.equal(normalizeRecognizedNumber('RPM'),null);
});

test('labels add/remove fuel and computes final map value',()=>{
  assert.equal(adjustmentLabel(2.4),'加油 +2.4');
  assert.equal(adjustmentLabel(-1.6),'減油 -1.6');
  assert.equal(adjustmentLabel(0),'不需修改');
  assert.equal(adjustedFuelValue(100,2.4),102.4);
  assert.equal(adjustedFuelValue(98.4,-1.6),96.8);
});

test('maps OCR tokens by RPM and TPS headers',()=>{
  const vertical=[0,100,200,300];
  const horizontal=[0,60,120,180];
  const token=(text,left,top,confidence=90)=>({text,left,top,width:30,height:20,confidence});
  const cells=tokensToFuelCells([
    token('800',120,15),token('1600',220,15),
    token('0',20,75),token('100',120,75),token('101.6',220,75),
    token('2',20,135),token('99.2',120,135),token('100',220,135)
  ],vertical,horizontal,'fixture.png');
  assert.deepEqual(cells.map(({tps,rpm,value})=>({tps,rpm,value})),[
    {tps:0,rpm:800,value:100},{tps:0,rpm:1600,value:101.6},
    {tps:2,rpm:800,value:99.2},{tps:2,rpm:1600,value:100}
  ]);
});

test('infers blurred leading RPM headers from clear 800-step screenshot labels',()=>{
  const vertical=[0,100,200,300,400,500,600,700];
  const horizontal=[0,60,120];
  const token=(text,left,top,confidence=90)=>({text,left,top,width:30,height:20,confidence});
  const cells=tokensToFuelCells([
    token('3200',420,15),token('4000',520,15),token('4800',620,15),
    token('0',20,75),
    token('94.5',120,75),token('93.0',220,75),token('77.3',320,75),
    token('80.5',420,75),token('80.5',520,75),token('80.5',620,75)
  ],vertical,horizontal,'fixture.png');
  assert.deepEqual(cells.map(cell=>cell.rpm),[800,1600,2400,3200,4000,4800]);
});

test('infers a blurred TPS label from its position in the ordered axis',()=>{
  const vertical=[0,100,200];
  const horizontal=[0,60,120,180,240];
  const token=(text,left,top,confidence=90)=>({text,left,top,width:30,height:20,confidence});
  const cells=tokensToFuelCells([
    token('800',120,15),
    token('0',20,75),token('4',20,195),
    token('94.5',120,75),token('93.0',120,135),token('87.5',120,195)
  ],vertical,horizontal,'fixture.png');
  assert.deepEqual(cells.map(({tps,value})=>({tps,value})),[
    {tps:0,value:94.5},{tps:2,value:93},{tps:4,value:87.5}
  ]);
});

test('merges overlapping screenshots and marks conflicting values',()=>{
  mergeRecognizedCells([{tps:10,rpm:3200,value:100,confidence:80,source:'a'}]);
  const result=mergeRecognizedCells([{tps:10,rpm:3200,value:100.8,confidence:90,source:'b'}]);
  assert.equal(result.conflicts,1);
  assert.equal(getCurrentFuelValue(10,3200),100.8);
});
