import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeRecognizedNumber,adjustmentLabel,adjustedFuelValue,
  mergeRecognizedCells,getCurrentFuelValue,tokensToFuelCells
} from '../src/screenshot-map.js';

test('normalizes OCR number variants without inventing empty values',()=>{
  assert.equal(normalizeRecognizedNumber(' +100.8% '),100.8);
  assert.equal(normalizeRecognizedNumber('−1,6'),-1.6);
  assert.equal(normalizeRecognizedNumber('O.8'),0.8);
  assert.equal(normalizeRecognizedNumber('RPM'),null);
});

test('labels add/remove fuel and computes final map value',()=>{
  assert.equal(adjustmentLabel(2.4),'加油 +2.4');
  assert.equal(adjustmentLabel(-1.6),'減油 -1.6');
  assert.equal(adjustmentLabel(0),'不需修改');
  assert.equal(adjustedFuelValue(100,2.4),102.4);
  assert.equal(adjustedFuelValue(98.4,-1.6),96.8);
});

test('maps OCR tokens by RPM and TPS headers',()=>{
  const vertical=[0,100,200,300];
  const horizontal=[0,60,120,180];
  const token=(text,left,top,confidence=90)=>({text,left,top,width:30,height:20,confidence});
  const cells=tokensToFuelCells([
    token('800',120,15),token('1200',220,15),
    token('0',20,75),token('100',120,75),token('101.6',220,75),
    token('2',20,135),token('99.2',120,135),token('100',220,135)
  ],vertical,horizontal,'fixture.png');
  assert.deepEqual(cells.map(({tps,rpm,value})=>({tps,rpm,value})),[
    {tps:0,rpm:800,value:100},{tps:0,rpm:1200,value:101.6},
    {tps:2,rpm:800,value:99.2},{tps:2,rpm:1200,value:100}
  ]);
});

test('merges overlapping screenshots and marks conflicting values',()=>{
  mergeRecognizedCells([{tps:10,rpm:3200,value:100,confidence:80,source:'a'}]);
  const result=mergeRecognizedCells([{tps:10,rpm:3200,value:100.8,confidence:90,source:'b'}]);
  assert.equal(result.conflicts,1);
  assert.equal(getCurrentFuelValue(10,3200),100.8);
});
