import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const read=path=>readFileSync(new URL(`../${path}`,import.meta.url),'utf8');

test('Fuel_CL UI exposes only include and exclude choices',()=>{
  const index=read('index.html');
  const select=index.match(/<select id="fuelClMode">([\s\S]*?)<\/select>/)?.[1]??'';
  assert.equal((select.match(/<option /g)??[]).length,2);
  assert.match(select,/不納入/);
  assert.match(select,/納入（MiniXX）/);
  assert.doesNotMatch(select,/positive_removes/);
});

test('advanced settings and result details are collapsed by default',()=>{
  const index=read('index.html');
  assert.match(index,/<details class="advancedSettings">/);
  assert.match(index,/<details class="card resultDetails">/);
  assert.doesNotMatch(index,/<details[^>]+open/);
});

test('confidence legend uses requested high and medium colors and hides low suggestions',()=>{
  const index=read('index.html');
  const css=read('views.css');
  assert.match(index,/綠色：高可信度/);
  assert.match(index,/黃色：中可信度/);
  assert.match(index,/低可信度：不顯示建議/);
  assert.match(css,/\.map td\.confidence-high/);
  assert.match(css,/\.map td\.confidence-medium/);
});

test('FAQ feedback fields and guide abbreviation table are present',()=>{
  const faq=read('faq.html');
  const guide=read('guide.html');
  assert.match(faq,/id="feedbackTitle"/);
  assert.match(faq,/id="feedbackMessage"/);
  assert.match(faq,/開啟問題回報頁/);
  for(const term of ['AFR','WBO2','Fuel_CL','TPS','RPM','T_Eng','FuelPW','Acc_Fuel_Mult','SA']){
    assert.match(guide,new RegExp(term));
  }
});

test('screenshot preview is local, optional, and requires confirmation',()=>{
  const index=read('index.html');
  const app=read('src/app.js');
  assert.match(index,/id="mapShots"[^>]+accept="image\/jpeg,image\/png,image\/webp"/);
  assert.match(index,/辨識結果確認/);
  assert.match(index,/沒有截圖仍可分析 Log/);
  assert.match(index,/tesseract\.min\.js/);
  assert.match(app,/adjustmentLabel/);
  assert.match(app,/目前.*最終/);
  assert.match(app,/c\.status!==\x27Adjust\x27/);
  assert.doesNotMatch(app,/未達建議門檻/);
});
