import test from 'node:test';
import assert from 'node:assert/strict';
import {parseLogText,analyzeLogs,analyzeIgnition,getEcuProfile,ignitionToCsv,reportToCsv,compareReports,comparisonToCsv,temperatureWeight,DEFAULT_SETTINGS} from '../src/analyzer.js';

function logRows({afr=15.4,target=14.7,tps=40,rpm=4000,temp=80,n=30,accAt=-1,fuelPW=2,fuelCL=1,sa=28,tempFn=null,afrFn=null}={}) {
  const h='Time,AFR_Target,AFR_WBO2,Fuel_CL,RPM,TPS_Percent,T_Eng,Acc_Fuel_Mult,WBO2_Ready,Cyl1_Comn_FuelPW,Cyl1_Eng_AP,Cyl1_Final_VM,SA';
  const rows=[];
  for(let i=0;i<n;i++){
    const tt=tempFn?tempFn(i):temp;
    const aa=afrFn?afrFn(i):afr;
    rows.push(`${(i/10).toFixed(1)},${target},${aa},${fuelCL},${rpm},${tps},${tt},${i===accAt?0.12:0},1,${fuelPW},70,100,${sa}`);
  }
  return h+'\n'+rows.join('\n');
}

test('AFR correction direction and magnitude',()=>{
  const rows=parseLogText(logRows());
  const c=analyzeLogs([{name:'a.loga',rows}]).cells[0];
  assert.equal(c.theoreticalCorrectionPct,4.76);
  assert.equal(c.suggestedCorrectionPct,4.8);
});

test('stable-time and per-cell sample defaults are conservative',()=>{
  assert.equal(DEFAULT_SETTINGS.minStableSecondsAfterWait,1);
  assert.equal(DEFAULT_SETTINGS.minSamplesPerCell,20);
});

test('selected minimum samples gates actionable fuel suggestions',()=>{
  const rows=parseLogText(logRows({n:35})); // 30 accepted after the 0.5 s entry wait
  assert.equal(analyzeLogs([{name:'a',rows}],{minSamplesPerCell:20}).cells[0].status,'Adjust');
  const guarded=analyzeLogs([{name:'a',rows}],{minSamplesPerCell:50}).cells[0];
  assert.equal(guarded.samples,30);
  assert.equal(guarded.status,'Monitor');
  assert.equal(guarded.suggestedCorrectionPct,0);
});

test('TPS 0 idle cell can produce a correction',()=>{
  const rows=parseLogText(logRows({tps:0}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.status,'Adjust');
  assert.equal(c.suggestedCorrectionPct,4.8);
});

test('minimum temperature excludes data',()=>{
  const rows=parseLogText(logRows({temp:50}));
  const r=analyzeLogs([{name:'a',rows}]);
  assert.equal(r.cells.length,0);
  assert.equal(r.exclusions.engine_temp,30);
});

test('suggestion respects the 5 percent cap and MiniXX 0.8 step',()=>{
  const rows=parseLogText(logRows({afr:17}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.suggestedCorrectionPct,4.8);
  assert.ok(c.theoreticalCorrectionPct>5);
});

test('acceleration enrichment excludes one second and splits steady state',()=>{
  const rows=parseLogText(logRows({n:50,accAt:15}));
  const r=analyzeLogs([{name:'a',rows}]);
  assert.ok(r.exclusions.after_acc_fuel>=10);
});

test('multi log disagreement becomes Verify',()=>{
  const a=parseLogText(logRows({afr:15.4,n:35}));
  const b=parseLogText(logRows({afr:13.7,n:35}));
  const c=analyzeLogs([{name:'a',rows:a},{name:'b',rows:b}]).cells[0];
  assert.equal(c.consistency,'Mixed');
  assert.equal(c.status,'Verify');
  assert.equal(c.suggestedCorrectionPct,0);
});

test('MiniX millisecond Time auto-normalizes to seconds',()=>{
  const h='Time,AFR_Target,AFR_WBO2,RPM,TPS_Percent,T_Eng,Acc_Fuel_Mult,Cyl1_Comn_FuelPW';
  const rows=parseLogText(h+'\n0,14.7,15.0,4000,40,80,0,2\n100,14.7,15.0,4000,40,80,0,2\n200,14.7,15.0,4000,40,80,0,2');
  assert.equal(rows[1].time,0.1);
  assert.equal(rows.meta.timeScale,0.001);
});

test('90-100C has highest temperature weight',()=>{
  assert.ok(temperatureWeight(95)>temperatureWeight(85));
  assert.ok(temperatureWeight(95)>temperatureWeight(105));
  assert.ok(temperatureWeight(95)>temperatureWeight(70));
});

test('temperature weighted correction influences V4 blended result',()=>{
  const rows=parseLogText(logRows({
    n:40,
    tempFn:i=>i<20?70:95,
    afrFn:i=>i<20?15.0:15.8,
    target:14.7
  }));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  const unweighted=((15.0/14.7-1)*100*15 + (15.8/14.7-1)*100*20)/35;
  assert.ok(c.weightedCorrectionPct>unweighted);
  assert.ok(c.theoreticalCorrectionPct>unweighted);
});

test('Fuel_CL support does not create correction alone',()=>{
  const rows=parseLogText(logRows({afr:14.7,target:14.7,fuelCL:6,n:35}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.theoreticalCorrectionPct,0);
  assert.equal(c.suggestedCorrectionPct,0);
  assert.equal(c.fuelClIncluded,false);
});

test('Fuel_CL is ignored when its mode is off',()=>{
  const rows=parseLogText(logRows({afr:15.4,target:14.7,fuelCL:-4,n:35}));
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.fuelClIncluded,false);
  assert.equal(c.status,'Adjust');
  assert.equal(c.suggestedCorrectionPct,4.8);
});

test('closed-loop Fuel_CL can recover base-map correction hidden by target AFR',()=>{
  const rows=parseLogText(logRows({afr:14.7,target:14.7,fuelCL:6,n:35}));
  const c=analyzeLogs([{name:'a',rows}],{fuelClMode:'positive_adds'}).cells[0];
  assert.equal(c.afrResidualCorrectionPct,0);
  assert.equal(c.theoreticalCorrectionPct,6);
  assert.equal(c.suggestedCorrectionPct,4.8);
  assert.equal(c.fuelClIncluded,true);
});

test('closed-loop uses multiplicative AFR and Fuel_CL conversion per row',()=>{
  const rows=parseLogText(logRows({afr:14.7*1.03,target:14.7,fuelCL:5,n:35}));
  const c=analyzeLogs([{name:'a',rows}],{fuelClMode:'positive_adds'}).cells[0];
  assert.equal(c.theoreticalCorrectionPct,8.15);
});

test('closed-loop mode rejects a log without Fuel_CL',()=>{
  const text='Time,AFR_Target,AFR_WBO2,RPM,TPS_Percent,T_Eng\n0,14.7,15,4000,40,80\n0.1,14.7,15,4000,40,80';
  const rows=parseLogText(text,'no-cl.loga');
  assert.throws(()=>analyzeLogs([{name:'no-cl.loga',rows}],{fuelClMode:'positive_adds'}),/沒有有效 Fuel_CL/);
});

test('large Fuel_CL raw value is Verify and never actionable',()=>{
  const rows=parseLogText(logRows({afr:14.7,target:14.7,fuelCL:21,n:35}));
  const c=analyzeLogs([{name:'a',rows}],{fuelClMode:'positive_adds'}).cells[0];
  assert.equal(c.status,'Verify');
  assert.equal(c.suggestedCorrectionPct,0);
});

test('V4 sample thresholds are strict greater-than',()=>{
  // 15 accepted samples after the 0.5s entry wait: 3% class must be >15, so no adjust.
  const rows=parseLogText(logRows({afr:15.2,target:14.7,n:20})); // raw ~3.4%; first 5 wait => 15 accepted
  const c=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(c.samples,15);
  assert.equal(c.status,'Monitor');
});

test('MiniXX suggestions are rounded to the nearest 0.8 adjustment step',()=>{
  const plus22=parseLogText(logRows({afr:14.7*1.022,target:14.7,n:35}));
  const plus38=parseLogText(logRows({afr:14.7*1.038,target:14.7,n:35}));
  assert.equal(analyzeLogs([{name:'a',rows:plus22}]).cells[0].suggestedCorrectionPct,2.4);
  assert.equal(analyzeLogs([{name:'b',rows:plus38}]).cells[0].suggestedCorrectionPct,4);
});

test('Low confidence never produces an actionable suggestion',()=>{
  const rows=parseLogText(logRows({afr:16,target:14.7,n:17}));
  const cell=analyzeLogs([{name:'a',rows}]).cells[0];
  assert.equal(cell.confidence,'Low');
  assert.equal(cell.status,'Monitor');
  assert.equal(cell.suggestedCorrectionPct,0);
});

test('High confidence requires at least 30 accepted samples',()=>{
  const short=parseLogText(logRows({afr:15.4,n:30})); // accepted ~25
  const c1=analyzeLogs([{name:'a',rows:short}]).cells[0];
  assert.notEqual(c1.confidence,'High');
  const long=parseLogText(logRows({afr:15.4,n:70}));
  const c2=analyzeLogs([{name:'a',rows:long}]).cells[0];
  assert.equal(c2.samples>=30,true);
});

test('MiniXX profile uses the supplied two-stage 55×17 fuel grid and fixed 20×9 ignition grid',()=>{
  const mini=getEcuProfile('MiniXX');
  assert.deepEqual(mini.fuelRpmAxis,[800,1200,1600,2000,2400,2800,3200,3600,4000,4400,4800,5200,5600,6000,6400,6800,7200,7600,8000,8400,8800,9200,9600,9800,10000,10200,10400,10600,10800,11000,11200,11400,11600,11800,12000,12200,12400,12600,12800,13000,13200,13400,13600,13800,14000,14200,14400,14600,14800,15000,15200,15400,15600,15800,16000]);
  assert.equal(mini.fuelTpsAxis.length,17);
  assert.equal(mini.ignitionRpmAxis.length,20);
  assert.equal(mini.ignitionTpsAxis.length,9);
  assert.throws(()=>getEcuProfile('AnotherECU'),/不支援的 ECU 型號/);
});

test('actual ignition analysis reads SA and uses the MiniXX 20×9 map',()=>{
  const rows=parseLogText(logRows({n:30,sa:27.5}));
  const report=analyzeIgnition([{name:'mini.loga',rows}],{ecuModel:'MiniXX'});
  assert.equal(report.grid,'20×9');
  assert.equal(report.cells.length,1);
  assert.equal(report.cells[0].actualSaMedian,27.5);
  assert.equal(report.cells[0].actualSaMin,27.5);
  assert.equal(report.cells[0].actualSaMax,27.5);
  assert.equal(report.summary.acceptedRows,30);
});

test('ignition CSV identifies ECU model and actual SA values',()=>{
  const rows=parseLogText(logRows({sa:31.25}));
  const report=analyzeIgnition([{name:'mini.loga',rows}],{ecuModel:'MiniXX'});
  const csv=ignitionToCsv(report);
  assert.match(csv,/ECU Model/);
  assert.match(csv,/MiniXX/);
  assert.match(csv,/31\.25/);
});

test('ignition-only log can be parsed without AFR columns',()=>{
  const text='Time,RPM,TPS_Percent,T_Eng,SA\n0,4000,40,80,26\n0.1,4000,40,80,28';
  const rows=parseLogText(text,'ignition-only.loga');
  const report=analyzeIgnition([{name:'ignition-only.loga',rows}],{ecuModel:'MiniXX'});
  assert.equal(report.cells[0].actualSaMedian,27);
  assert.equal(report.cells[0].effectiveSeconds,0.1);
});

test('ignition analysis excludes engine-off and out-of-axis samples',()=>{
  const text='Time,RPM,TPS_Percent,T_Eng,Cyl1_Comn_FuelPW,SA\n0,0,0,80,2,5\n0.1,4000,40,80,0,28\n0.2,4000,40,80,2,30';
  const rows=parseLogText(text,'quality.loga');
  const report=analyzeIgnition([{name:'quality.loga',rows}],{ecuModel:'MiniXX'});
  assert.equal(report.summary.acceptedRows,1);
  assert.equal(report.summary.exclusions.outOfAxis,1);
  assert.equal(report.summary.exclusions.fuelCut,1);
});

test('unsupported ECU model is rejected instead of silently using MiniXX',()=>{
  assert.throws(()=>getEcuProfile('UnknownXX'),/不支援的 ECU 型號/);
});

test('fuel CSV records Fuel_CL mode and AFR-to-fuel conversion',()=>{
  const rows=parseLogText(logRows({n:35,fuelCL:5}));
  const report=analyzeLogs([{name:'a',rows}],{fuelClMode:'positive_adds'});
  const csv=reportToCsv(report);
  assert.match(csv,/Fuel_CL mode/);
  assert.match(csv,/正值＝ECU 加油/);
  assert.match(csv,/AFR residual correction/);
});

test('before-after comparison classifies lower absolute error as improved',()=>{
  const beforeRows=parseLogText(logRows({afr:15.7,target:14.7,n:35}));
  const afterRows=parseLogText(logRows({afr:15.0,target:14.7,n:35}));
  const comparison=compareReports(
    analyzeLogs([{name:'before',rows:beforeRows}]),
    analyzeLogs([{name:'after',rows:afterRows}])
  );
  assert.equal(comparison.summary.comparable,1);
  assert.equal(comparison.summary.improved,1);
  assert.equal(comparison.cells[0].result,'Improved');
  assert.match(comparisonToCsv(comparison),/Absolute error change/);
});
